"use client"

import { useState, useEffect, useRef } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { ArrowLeft, Send, Check, MessageSquare, Calendar, Users, Clock } from "lucide-react"
import Button from "../../components/dept/Button"
import Modal from "../../components/dept/Modal"
import apiClient from "../../utils/apiClient"
import { useToast } from "../../context/ToastContext"
import { useAuth } from "../../context/AuthContext"
import { io } from "socket.io-client"
import { format } from "date-fns"

const ClashDetails = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { addToast } = useToast()
  const { user } = useAuth()
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false)
  const [clashDetails, setClashDetails] = useState(null)
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [socket, setSocket] = useState(null)
  const messagesEndRef = useRef(null)
  const chatContainerRef = useRef(null)

  // Initialize socket connection
  useEffect(() => {
    const socketInstance = io(import.meta.env.VITE_API_BASE_URL || "http://localhost:3000")
    setSocket(socketInstance)

    // Clean up on unmount
    return () => {
      if (socketInstance) socketInstance.disconnect()
    }
  }, [])

  // Set up socket event listeners
  useEffect(() => {
    if (!socket) return

    // Join the clash room
    socket.emit("joinRoom", id)

    // Listen for new messages
    socket.on("newMessage", (message) => {
      setMessages((prevMessages) => [...prevMessages, message])
    })

    // Clean up listeners on unmount
    return () => {
      socket.off("newMessage")
      socket.emit("leaveRoom", id)
    }
  }, [socket, id])

  // Fetch clash details and messages
  useEffect(() => {
    const fetchClashDetails = async () => {
      try {
        setLoading(true)
        const detailsResponse = await apiClient.get(`/uclashes/${id}/involved-departments`)

        if (detailsResponse.data.success) {
          setClashDetails(detailsResponse.data)
        } else {
          setError("Failed to fetch clash details")
          addToast("Failed to fetch clash details", "error")
        }

        // Fetch messages
        const messagesResponse = await apiClient.get(`/loadMessages/messages?clashId=${id.toLowerCase()}`)

        if (messagesResponse.data.messages) {
          setMessages(messagesResponse.data.messages)
        }
      } catch (err) {
        console.error("Error fetching clash data:", err)
        setError("Error fetching clash data")
        addToast("Error fetching clash data", "error")
      } finally {
        setLoading(false)
      }
    }

    if (id) {
      fetchClashDetails()
    }
  }, [id, addToast])

  // Scroll to bottom of messages when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = (e) => {
    e.preventDefault()
    if (!newMessage.trim() || !socket) return

    // In a real app, you would send this to the server via socket
    socket.emit("sendMessage", {
      clashID: id,
      message: newMessage,
      department: user?.deptId || "Unknown",
      email: user?.email || "user@example.com",
    })

    // Clear the input
    setNewMessage("")
  }

  const handleAccept = async () => {
    try {
      const response = await apiClient.put(`/uclashes/${id}/involved-departments`, {
        status: true,
      })

      if (response.data.success) {
        addToast("Roadmap accepted successfully", "success")

        // Refresh clash details
        const detailsResponse = await apiClient.get(`/uclashes/${id}/involved-departments`)
        if (detailsResponse.data.success) {
          setClashDetails(detailsResponse.data)
        }

        // If clash is resolved, navigate back to clashes page
        if (response.data.is_resolved) {
          navigate("/dashboard/dept/clashes")
        }
      } else {
        addToast("Failed to accept roadmap", "error")
      }
    } catch (err) {
      console.error("Error accepting roadmap:", err)
      addToast("Error accepting roadmap", "error")
    } finally {
      setIsConfirmModalOpen(false)
    }
  }

  // Format date for display
  const formatDateString = (dateString) => {
    if (!dateString) return "N/A"
    try {
      return format(new Date(dateString), "dd MMM yyyy")
    } catch (error) {
      return dateString
    }
  }

  // Check if current department has accepted the roadmap
  const hasCurrentDeptAccepted = () => {
    if (!clashDetails || !user?.deptId) return false
    return clashDetails.involved_departments[user.deptId] === true
  }

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-900">
        <div className="flex flex-col items-center">
          <div className="h-16 w-16 border-4 border-t-blue-500 border-blue-200/30 rounded-full animate-spin"></div>
          <p className="mt-4 text-blue-400 font-medium">Loading clash details...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <div className="text-red-500 mb-4">{error}</div>
        <Button onClick={() => navigate("/dashboard/dept/clashes")}>Back to Clashes</Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="container mx-auto flex items-center">
          <button
            onClick={() => navigate("/dashboard/dept/clashes")}
            className="p-2 mr-3 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-xl font-bold flex items-center">
            Clash <span className="text-blue-400 ml-1">{id}</span>
            <span
              className={`ml-4 px-3 py-1 text-xs rounded-full ${
                clashDetails?.is_resolved
                  ? "bg-green-900/30 text-green-400 border border-green-700/50"
                  : "bg-yellow-900/30 text-yellow-400 border border-yellow-700/50"
              }`}
            >
              {clashDetails?.is_resolved ? "Resolved" : "Unresolved"}
            </span>
          </h1>
        </div>
      </div>

      <div className="container mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat Section */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden h-[calc(100vh-180px)] flex flex-col">
              <div className="p-4 border-b border-gray-700 flex items-center">
                <MessageSquare className="h-5 w-5 text-blue-400 mr-2" />
                <h2 className="text-lg font-semibold">
                  Department Chat
                  <span className="ml-2 inline-flex h-2 w-2 rounded-full bg-green-400"></span>
                </h2>
              </div>

              <div
                ref={chatContainerRef}
                className="flex-1 overflow-y-auto p-4 space-y-4"
                style={{ scrollBehavior: "smooth" }}
              >
                {messages.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center text-gray-500 p-6 bg-gray-800/50 rounded-lg border border-gray-700">
                      <MessageSquare className="h-10 w-10 mx-auto mb-2 opacity-50" />
                      <p className="text-lg font-medium">No messages yet</p>
                      <p className="text-sm">Start the conversation with other departments</p>
                    </div>
                  </div>
                ) : (
                  messages.map((message, index) => {
                    const isCurrentDept = message.deptId === user?.deptId
                    return (
                      <div
                        key={message.id || index}
                        className={`flex ${isCurrentDept ? "justify-end" : "justify-start"} animate-fadeIn`}
                        style={{ animationDelay: `${index * 100}ms` }}
                      >
                        {!isCurrentDept && (
                          <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-xs font-medium mr-2 flex-shrink-0">
                            {message.deptId?.substring(0, 2)}
                          </div>
                        )}
                        <div
                          className={`max-w-[80%] rounded-lg px-4 py-3 shadow-lg ${
                            isCurrentDept ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-100"
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span
                              className={`font-medium text-sm ${isCurrentDept ? "text-blue-200" : "text-gray-300"}`}
                            >
                              {message.deptId}
                            </span>
                            <span className="text-xs ml-2 opacity-75">
                              {new Date(message.createdAt).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                          <p className="leading-relaxed">{message.message}</p>
                        </div>
                        {isCurrentDept && (
                          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-xs font-medium text-white ml-2 flex-shrink-0">
                            {message.deptId?.substring(0, 2)}
                          </div>
                        )}
                      </div>
                    )
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-700 bg-gray-800">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Type your message..."
                    className="flex-1 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                  />
                  <Button type="submit" className="px-4 bg-blue-600 hover:bg-blue-700">
                    <Send size={18} className="mr-2" />
                    Send
                  </Button>
                </div>
              </form>
            </div>
          </div>

          {/* Roadmap and Departments Section */}
          <div className="lg:col-span-1 space-y-6">
            {/* Proposed Roadmap */}
            <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
              <div className="p-4 border-b border-gray-700 flex items-center">
                <Calendar className="h-5 w-5 text-blue-400 mr-2" />
                <h2 className="text-lg font-semibold">Proposed Roadmap</h2>
              </div>

              <div className="p-4 space-y-4">
                {clashDetails &&
                  Object.keys(clashDetails.start_dates || {}).map((deptId, index) => (
                    <div
                      key={deptId}
                      className="relative overflow-hidden rounded-lg border border-gray-700 hover:border-blue-500 transition-all duration-300 group"
                    >
                      {/* Priority indicator */}
                      <div className="absolute top-0 right-0 px-2 py-1 text-xs font-medium bg-blue-900/50 text-blue-300 rounded-bl-lg">
                        Priority {index + 1}
                      </div>

                      {/* Department indicator */}
                      <div className="p-3 bg-gray-700/50 flex items-center">
                        <div className="w-2 h-full rounded-full bg-blue-500 absolute left-0 top-0 bottom-0"></div>
                        <div className="ml-3 font-medium">{deptId}</div>
                      </div>

                      {/* Date information */}
                      <div className="p-3 grid grid-cols-2 gap-3">
                        <div className="bg-gray-700/30 p-2 rounded-md">
                          <div className="text-xs text-gray-400 mb-1 flex items-center">
                            <Clock className="h-3 w-3 mr-1" /> Start Date
                          </div>
                          <div className="font-medium text-blue-300">
                            {formatDateString(clashDetails.start_dates[deptId])}
                          </div>
                        </div>
                        <div className="bg-gray-700/30 p-2 rounded-md">
                          <div className="text-xs text-gray-400 mb-1 flex items-center">
                            <Clock className="h-3 w-3 mr-1" /> End Date
                          </div>
                          <div className="font-medium text-blue-300">
                            {formatDateString(clashDetails.end_dates[deptId])}
                          </div>
                        </div>
                      </div>

                      {/* Hover effect */}
                      <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                    </div>
                  ))}
              </div>

              {/* Accept roadmap button */}
              <div className="p-4 border-t border-gray-700">
                {clashDetails && !clashDetails.is_resolved && !hasCurrentDeptAccepted() ? (
                  <Button
                    className="w-full bg-blue-600 hover:bg-blue-700 transition-all duration-300 transform hover:scale-105"
                    onClick={() => setIsConfirmModalOpen(true)}
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Accept Roadmap
                  </Button>
                ) : clashDetails && !clashDetails.is_resolved && hasCurrentDeptAccepted() ? (
                  <div className="w-full p-3 bg-green-900/30 text-green-400 border border-green-700/50 rounded-lg text-center">
                    <Check className="h-4 w-4 inline-block mr-2" />
                    You have accepted this roadmap
                  </div>
                ) : null}
              </div>
            </div>

            {/* Departments Involved */}
            <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
              <div className="p-4 border-b border-gray-700 flex items-center">
                <Users className="h-5 w-5 text-blue-400 mr-2" />
                <h2 className="text-lg font-semibold">Departments Involved</h2>
              </div>

              <div className="divide-y divide-gray-700">
                {clashDetails &&
                  Object.keys(clashDetails.involved_departments || {}).map((deptId) => (
                    <div
                      key={deptId}
                      className="flex items-center justify-between p-4 hover:bg-gray-700/30 transition-colors"
                    >
                      <div className="flex items-center">
                        <div
                          className={`w-2 h-2 rounded-full mr-3 ${
                            clashDetails.involved_departments[deptId] ? "bg-green-400" : "bg-yellow-400"
                          }`}
                        ></div>
                        <span className="font-medium">{deptId}</span>
                      </div>
                      <div
                        className={`flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                          clashDetails.involved_departments[deptId]
                            ? "bg-green-900/30 text-green-400 border border-green-700/50"
                            : "bg-yellow-900/30 text-yellow-400 border border-yellow-700/50"
                        }`}
                      >
                        {clashDetails.involved_departments[deptId] ? (
                          <>
                            <Check className="h-3 w-3 mr-1" />
                            Accepted
                          </>
                        ) : (
                          <>
                            <Clock className="h-3 w-3 mr-1" />
                            Pending
                          </>
                        )}
                      </div>
                    </div>
                  ))}
              </div>

              {/* Summary */}
              <div className="p-4 border-t border-gray-700 bg-gray-700/30">
                <div className="text-sm text-gray-400">
                  {clashDetails && Object.values(clashDetails.involved_departments).filter(Boolean).length} of{" "}
                  {clashDetails && Object.keys(clashDetails.involved_departments).length} departments have accepted
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      <Modal
        isOpen={isConfirmModalOpen}
        onClose={() => setIsConfirmModalOpen(false)}
        title="Confirm Roadmap Acceptance"
      >
        <div className="text-center p-6">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-blue-900/30 mb-6">
            <Check className="h-8 w-8 text-blue-400" />
          </div>
          <h3 className="text-xl font-medium text-white mb-4">Accept Proposed Roadmap?</h3>
          <p className="text-gray-400 mb-6">
            By accepting this roadmap, you agree to the proposed schedule for your department's work. This action cannot
            be reversed.
          </p>
          <div className="flex justify-center space-x-4">
            <Button
              variant="secondary"
              onClick={() => setIsConfirmModalOpen(false)}
              className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600"
            >
              Cancel
            </Button>
            <Button onClick={handleAccept} className="bg-blue-600 hover:bg-blue-700">
              Confirm Acceptance
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default ClashDetails

