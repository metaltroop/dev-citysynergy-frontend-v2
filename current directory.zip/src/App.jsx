import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import { AuthProvider } from "./context/AuthContext"
import { LoadingProvider } from "./context/LoadingContext"
import { AuthGuard } from "./components/AuthGuard"
import { Home } from "./pages/Home"
import { Login } from "./pages/Login"
import { OTPVerification } from "./pages/OTPVerification"
import DashboardRouter from "./pages/DashboardRouter"

export default function App() {
  return (
    <LoadingProvider>
      <Router>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Navigate to="/home" replace />} />
            <Route path="/home" element={<Home />} />
            <Route
              path="/login"
              element={
                <AuthGuard>
                  <Login />
                </AuthGuard>
              }
            />
            
            <Route
              path="/verify-otp"
              element={
                <AuthGuard>
                  <OTPVerification />
                </AuthGuard>
              }
            />
            <Route
              path="/dashboard/*"
              element={
                <AuthGuard requireAuth>
                  <DashboardRouter />
                </AuthGuard>
              }
            />
          </Routes>
        </AuthProvider>
      </Router>
    </LoadingProvider>
  )
}

