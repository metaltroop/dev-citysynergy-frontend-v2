import { useState, useEffect } from "react"
import { RefreshCcw } from "lucide-react"
import apiClient from "../../utils/apiClient"

/**
 * ProfileImage component for displaying user profile images
 * @param {Object} props
 * @param {string} props.username - User's name for initials fallback
 * @param {string} props.userId - User ID to fetch specific user's image
 * @param {string} props.size - Size of the image (sm, md, lg, xl)
 * @param {Function} props.onClick - Click handler for the image
 */
const ProfileImage = ({ username, userId, size = "md", onClick }) => {
  const [profileImage, setProfileImage] = useState(null)
  const [loading, setLoading] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [imageError, setImageError] = useState(false)

  // Size classes mapping
  const sizeClasses = {
    sm: "h-9 w-9",
    md: "h-12 w-12",
    lg: "h-16 w-16",
    xl: "h-24 w-24",
  }

  // Font size classes mapping for initials
  const fontSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
    xl: "text-xl",
  }

  // Get initials from username
  const getInitials = () => {
    if (!username) return "U"
    return username
      .split(" ")
      .map((name) => name[0])
      .join("")
      .toUpperCase()
      .substring(0, 2)
  }

  // Fetch profile image
  const fetchProfileImage = async () => {
    if (!userId) {
      setImageError(true)
      return
    }
    
    setLoading(true)
    try {
      const response = await apiClient.get(`/users/${userId}/profile-image`, {
        responseType: 'blob'
      })
      
      if (response?.data) {
        const imageUrl = URL.createObjectURL(response.data)
        setProfileImage(imageUrl)
        setImageError(false)
      } else {
        setImageError(true)
      }
    } catch (error) {
      console.error('Error fetching profile image:', error)
      setImageError(true)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchProfileImage()
    // Cleanup function to revoke object URL when component unmounts
    return () => {
      if (profileImage) {
        URL.revokeObjectURL(profileImage)
      }
    }
  }, [userId])

  const handleClick = () => {
    if (onClick) {
      onClick()
    } else {
      setShowModal(true)
    }
  }

  const handleImageError = () => {
    setImageError(true)
  }

  return (
    <>
      <div className={`${sizeClasses[size]} rounded-full overflow-hidden cursor-pointer`} onClick={handleClick}>
        {loading ? (
          <div className="h-full w-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
            <RefreshCcw className="h-1/3 w-1/3 text-gray-400 dark:text-gray-500 animate-spin" />
          </div>
        ) : profileImage && !imageError ? (
          <img
            src={profileImage}
            alt={username || "Profile"}
            className="h-full w-full object-cover"
            onError={handleImageError}
          />
        ) : (
          <div className={`h-full w-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium ${fontSizeClasses[size]}`}>
            {getInitials()}
          </div>
        )}
      </div>

      {/* Profile Image Modal - Attached to document body */}
      {showModal && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={() => setShowModal(false)}
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
        >
          <div
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 max-w-md w-full mx-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Profile Image</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path
                    fillRule="evenodd"
                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                    clipRule="evenodd"
                  />
                </svg>
              </button>
            </div>
            <div className="flex flex-col items-center justify-center">
              <div className="h-40 w-40 rounded-full overflow-hidden mb-4">
                {profileImage && !imageError ? (
                  <img
                    src={profileImage}
                    alt={username || "Profile"}
                    className="h-full w-full object-cover"
                    onError={handleImageError}
                  />
                ) : (
                  <div className="h-full w-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white text-4xl font-medium">
                    {getInitials()}
                  </div>
                )}
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-center font-medium text-lg">{username || "User"}</p>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default ProfileImage