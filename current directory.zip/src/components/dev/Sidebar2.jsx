import { Link, useLocation } from "react-router-dom"
import { 
  LayoutDashboard, 
  Users, 
  FolderTree, 
  ShieldCheck, 
  Layers, 
  AlertTriangle,
  Settings,
  LogOut,
  ChevronRight
} from "lucide-react"
import { useState } from "react"

const navItems = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/users", label: "Users", icon: Users },
  { path: "/departments", label: "Departments", icon: FolderTree },
  { path: "/roles", label: "Roles", icon: ShieldCheck },
  { path: "/features", label: "Features", icon: Layers },
  { path: "/clashes", label: "Clashes", icon: AlertTriangle },
]

const quickLinks = [
  { label: "Settings", icon: Settings },
  { label: "Logout", icon: LogOut },
]

export default function Sidebar() {
  const location = useLocation()
  const [hoverIndex, setHoverIndex] = useState(null)
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside className={`min-h-screen bg-white border-r border-gray-200 fixed shadow-sm transition-all duration-300 ${collapsed ? "w-20" : "w-64"}`}>
      <div className="flex flex-col h-full">
        {/* Logo area */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between">
            {!collapsed && (
              <h2 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                AdminPanel
              </h2>
            )}
            <button 
              onClick={() => setCollapsed(!collapsed)} 
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <ChevronRight className={`h-5 w-5 text-gray-500 transition-transform ${collapsed ? "rotate-180" : ""}`} />
            </button>
          </div>
        </div>
        
        {/* Main navigation */}
        <nav className="p-3 flex-grow">
          <div className={`${!collapsed ? "mb-3 px-3" : "mb-2"}`}>
            {!collapsed && <p className="text-xs uppercase text-gray-500 font-semibold">Main Navigation</p>}
            {collapsed && <div className="h-px bg-gray-200 my-2"></div>}
          </div>
          
          <div className="space-y-1">
            {navItems.map((item, index) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center px-3 py-2.5 rounded-lg transition-all ${
                  location.pathname === item.path 
                    ? "bg-blue-50 text-blue-600" 
                    : "text-gray-600 hover:bg-gray-50"
                } ${hoverIndex === index ? "shadow-sm" : ""}`}
                onMouseEnter={() => setHoverIndex(index)}
                onMouseLeave={() => setHoverIndex(null)}
              >
                <div className={`${location.pathname === item.path 
                  ? "bg-blue-100" 
                  : "bg-gray-100"} p-2 rounded-lg mr-3`}>
                  <item.icon className={`h-5 w-5 ${
                    location.pathname === item.path ? "text-blue-600" : "text-gray-500"
                  }`} />
                </div>
                {!collapsed && (
                  <span className={`font-medium ${location.pathname === item.path && "font-semibold"}`}>
                    {item.label}
                  </span>
                )}
                {!collapsed && location.pathname === item.path && (
                  <div className="ml-auto w-1.5 h-5 bg-blue-500 rounded-full"></div>
                )}
              </Link>
            ))}
          </div>
        </nav>
        
        {/* Quick links / footer */}
        <div className="mt-auto p-3 border-t border-gray-100">
          {!collapsed && (
            <p className="text-xs uppercase text-gray-500 font-semibold px-3 mb-2">Quick Links</p>
          )}
          <div className="space-y-1">
            {quickLinks.map((item, index) => (
              <a
                key={item.label}
                href="#"
                className="flex items-center px-3 py-2.5 rounded-lg transition-all text-gray-600 hover:bg-gray-50"
              >
                <div className="bg-gray-100 p-2 rounded-lg mr-3">
                  <item.icon className="h-5 w-5 text-gray-500" />
                </div>
                {!collapsed && <span className="font-medium">{item.label}</span>}
              </a>
            ))}
          </div>
        </div>
        
        {/* User profile */}
        {!collapsed && (
          <div className="p-4 border-t border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="h-9 w-9 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
                JD
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700">John Doe</p>
                <p className="text-xs text-gray-500">Administrator</p>
              </div>
            </div>
          </div>
        )}
        {collapsed && (
          <div className="p-3 border-t border-gray-100 flex justify-center">
            <div className="h-9 w-9 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
              JD
            </div>
          </div>
        )}
      </div>
    </aside>
  )
}