import { createContext } from "react";

// Export constants and utility functions
export const AuthContext = createContext(null);