"use client"

import { useState } from "react"
import SearchBar from "../../components/dev/SearchBar"

const dummyClashes = [
  {
    id: 1,
    info: "Resource allocation conflict",
    departments: [
      { id: "DEPT001", name: "Engineering" },
      { id: "DEPT002", name: "Marketing" },
    ],
    resolved: false,
  },
]

export default function Clashes() {
  const [searchTerm, setSearchTerm] = useState("")
  const [showResolved, setShowResolved] = useState(false)
  const [showDepartments, setShowDepartments] = useState(false)
  const [showDatePicker, setShowDatePicker] = useState(false)
  const [selectedClash, setSelectedClash] = useState(null)

  const filteredClashes = dummyClashes.filter(
    (clash) => clash.resolved === showResolved && clash.info.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-6">
        <SearchBar onSearch={setSearchTerm} />
      </div>

      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setShowResolved(false)}
          className={`px-4 py-2 rounded-md ${
            !showResolved ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          Unresolved
        </button>
        <button
          onClick={() => setShowResolved(true)}
          className={`px-4 py-2 rounded-md ${
            showResolved ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-700 hover:bg-gray-300"
          }`}
        >
          Resolved
        </button>
      </div>

      <div className="bg-white rounded-lg shadow">
        <table className="min-w-full">
          <thead>
            <tr className="bg-gray-50 border-b">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Clash Info</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredClashes.map((clash) => (
              <tr key={clash.id} className="border-b">
                <td className="px-6 py-4">{clash.info}</td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setSelectedClash(clash)
                        setShowDepartments(true)
                      }}
                      className="text-blue-500 hover:text-blue-700"
                    >
                      Involved Departments
                    </button>
                    <button
                      onClick={() => {
                        setSelectedClash(clash)
                        setShowDatePicker(true)
                      }}
                      className="text-blue-500 hover:text-blue-700"
                    >
                      Propose Date
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Departments Modal */}
      {showDepartments && selectedClash && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h3 className="text-lg font-bold mb-4">Involved Departments</h3>
            <table className="min-w-full">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-4 py-2 text-left">Department ID</th>
                  <th className="px-4 py-2 text-left">Name</th>
                </tr>
              </thead>
              <tbody>
                {selectedClash.departments.map((dept) => (
                  <tr key={dept.id} className="border-b">
                    <td className="px-4 py-2">{dept.id}</td>
                    <td className="px-4 py-2">{dept.name}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setShowDepartments(false)}
                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Date Picker Modal */}
      {showDatePicker && selectedClash && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg w-full max-w-md">
            <h3 className="text-lg font-bold mb-4">Propose Date</h3>
            <input type="date" className="w-full px-3 py-2 border rounded-md mb-4" />
            <div className="flex justify-end gap-2">
              <button onClick={() => setShowDatePicker(false)} className="px-4 py-2 text-gray-600 hover:text-gray-800">
                Cancel
              </button>
              <button
                onClick={() => {
                  console.log("Date proposed")
                  setShowDatePicker(false)
                }}
                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
              >
                Propose
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

