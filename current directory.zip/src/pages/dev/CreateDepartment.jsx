"use client"

import { useState } from "react"
import { useNavigate } from "react-router-dom"

const dummyUsers = [
  { id: 1, name: "John Metal", email: "john@example.com" },
  { id: 2, name: "Jane Smith", email: "jane@example.com" },
]

export default function CreateDepartment() {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    adminId: "",
  })
  const [searchTerm, setSearchTerm] = useState("")
  const [showSuggestions, setShowSuggestions] = useState(false)

  const filteredUsers = dummyUsers.filter((user) => user.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const handleSubmit = (e) => {
    e.preventDefault()
    console.log("Creating department:", formData)
    navigate("/departments")
  }

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow p-6">
      <h2 className="text-2xl font-bold mb-6">Create Department</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Department Name</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Department Code</label>
          <input
            type="text"
            value={formData.code}
            onChange={(e) => setFormData({ ...formData, code: e.target.value })}
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="relative">
          <label className="block text-sm font-medium text-gray-700 mb-1">Assign Admin</label>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value)
              setShowSuggestions(true)
            }}
            onFocus={() => setShowSuggestions(true)}
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {showSuggestions && (
            <div className="absolute w-full mt-1 bg-white border rounded-md shadow-lg z-10">
              {filteredUsers.map((user) => (
                <div
                  key={user.id}
                  className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => {
                    setFormData({ ...formData, adminId: user.id })
                    setSearchTerm(user.name)
                    setShowSuggestions(false)
                  }}
                >
                  {user.name}
                </div>
              ))}
            </div>
          )}
        </div>

        <button type="submit" className="w-full px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
          Create Department
        </button>
      </form>
    </div>
  )
}

