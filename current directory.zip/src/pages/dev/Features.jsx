"use client"

import { useState } from "react"
import SearchBar from "../../components/dev/SearchBar"

const dummyFeatures = [
  { id: 1, name: "User Management", description: "Manage system users" },
  { id: 2, name: "Department Control", description: "Control department settings" },
]

export default function Features() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredFeatures = dummyFeatures.filter(
    (feature) =>
      feature.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      feature.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-6">
        <SearchBar onSearch={setSearchTerm} />
      </div>

      <div className="bg-white rounded-lg shadow">
        <table className="min-w-full">
          <thead>
            <tr className="bg-gray-50 border-b">
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Feature Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Description</th>
            </tr>
          </thead>
          <tbody>
            {filteredFeatures.map((feature) => (
              <tr key={feature.id} className="border-b">
                <td className="px-6 py-4">{feature.name}</td>
                <td className="px-6 py-4">{feature.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

