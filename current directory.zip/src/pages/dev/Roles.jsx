"use client"

import { useState } from "react"
import SearchBar from "../../components/dev/SearchBar"
import Modal from "../../components/dev/Modal"
import { Shield, Plus, Edit, Trash2, Check } from "lucide-react"

const dummyRoles = [
  {
    id: "DROL001",
    name: "DevAdmin",
    description: "Developer administrator with full access",
    permissions: {
      "User Management": ["R", "W", "U", "D"],
      "Department Control": ["R", "W"],
      "System Settings": ["R", "W", "U"],
    },
  },
  {
    id: "DROL002",
    name: "System Owner",
    description: "System owner with complete control",
    permissions: {
      "User Management": ["R", "W", "U", "D"],
      "Department Control": ["R", "W", "U", "D"],
      "System Settings": ["R", "W", "U", "D"],
    },
  },
]

const features = ["User Management", "Department Control", "System Settings", "Report Generation", "API Access"]

const permissionTypes = [
  { key: "R", label: "Read" },
  { key: "W", label: "Write" },
  { key: "U", label: "Update" },
  { key: "D", label: "Delete" },
]

export default function Roles() {
  const [searchTerm, setSearchTerm] = useState("")
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showPermissionModal, setShowPermissionModal] = useState(false)
  const [selectedRole, setSelectedRole] = useState(null)
  const [newRole, setNewRole] = useState({ name: "", description: "" })
  const [permissions, setPermissions] = useState({})

  const filteredRoles = dummyRoles.filter((role) => role.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const handlePermissionChange = (feature, type) => {
    setPermissions((prev) => ({
      ...prev,
      [feature]: {
        ...prev[feature],
        [type]: !prev[feature]?.[type],
      },
    }))
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2">Role Management</h1>
          <p className="text-gray-600">Manage user roles and their permissions</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          <Plus className="h-5 w-5" />
          Add New Role
        </button>
      </div>

      <div className="mb-6">
        <SearchBar onSearch={setSearchTerm} />
      </div>

      <div className="grid gap-6">
        {filteredRoles.map((role) => (
          <div key={role.id} className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Shield className="h-6 w-6 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-semibold">{role.name}</h3>
                  <p className="text-sm text-gray-600">{role.description}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setSelectedRole(role)
                    setPermissions(role.permissions)
                    setShowPermissionModal(true)
                  }}
                  className="p-2 text-gray-600 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Edit className="h-5 w-5" />
                </button>
                <button className="p-2 text-gray-600 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {Object.entries(role.permissions).map(([feature, perms]) => (
                <div key={feature} className="bg-gray-50 rounded-lg p-3">
                  <p className="text-sm font-medium mb-2">{feature}</p>
                  <div className="flex gap-2">
                    {permissionTypes.map(({ key }) => (
                      <span
                        key={key}
                        className={`text-xs px-2 py-1 rounded ${
                          perms.includes(key) ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        {key}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Create Role Modal */}
      <Modal isOpen={showCreateModal} onClose={() => setShowCreateModal(false)} title="Create New Role">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Role Name</label>
            <input
              type="text"
              value={newRole.name}
              onChange={(e) => setNewRole({ ...newRole, name: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter role name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <input
              type="text"
              value={newRole.description}
              onChange={(e) => setNewRole({ ...newRole, description: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter role description"
            />
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <button onClick={() => setShowCreateModal(false)} className="px-4 py-2 text-gray-600 hover:text-gray-800">
              Cancel
            </button>
            <button
              onClick={() => {
                console.log("Creating role:", newRole)
                setShowCreateModal(false)
              }}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
            >
              Create Role
            </button>
          </div>
        </div>
      </Modal>

      {/* Edit Permissions Modal */}
      <Modal
        isOpen={showPermissionModal}
        onClose={() => setShowPermissionModal(false)}
        title={`Edit Permissions - ${selectedRole?.name}`}
        maxWidth="max-w-4xl"
      >
        <div className="space-y-6 overflow-y-auto max-h-[70vh]">
          <div className="grid gap-4">
            <div className="grid grid-cols-[2fr,repeat(4,1fr)] gap-4 px-4 py-2 bg-gray-50 rounded-lg">
              <div className="font-medium">Feature</div>
              {permissionTypes.map(({ key, label }) => (
                <div key={key} className="text-center font-medium">
                  {label}
                </div>
              ))}
            </div>
            {features.map((feature) => (
              <div
                key={feature}
                className="grid grid-cols-[2fr,repeat(4,1fr)] gap-4 px-4 py-2 items-center hover:bg-gray-50 rounded-lg"
              >
                <div>{feature}</div>
                {permissionTypes.map(({ key }) => (
                  <div key={key} className="flex justify-center">
                    <button
                      onClick={() => handlePermissionChange(feature, key)}
                      className={`p-2 rounded-lg ${
                        permissions[feature]?.[key] ? "bg-blue-100 text-blue-600" : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      <Check className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <button
              onClick={() => setShowPermissionModal(false)}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                console.log("Saving permissions:", permissions)
                setShowPermissionModal(false)
              }}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
            >
              Save Changes
            </button>
          </div>
        </div>
      </Modal>
    </div>
  )
}