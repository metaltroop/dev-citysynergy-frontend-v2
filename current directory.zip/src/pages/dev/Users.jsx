"use client"

import { useState } from "react"
import { Link } from "react-router-dom"
import SearchBar from "../../components/dev/SearchBar"
import { 
  Edit, 
  Trash2, 
  Key, 
  UserPlus, 
  Filter, 
  MoreVertical, 
  Download, 
  Upload, 
  RefreshCcw,
  CheckCircle,
  AlertCircle,
  Users as UsersIcon
} from "lucide-react"

// Extended dummy data with status and last login
const dummyUsers = [
  { 
    id: 1, 
    username: "john_dev", 
    email: "john@example.com", 
    type: "dev", 
    role: "DROL001", 
    status: "active",
    lastLogin: "2 hours ago",
    avatar: "JD",
    department: "Engineering"
  },
  { 
    id: 2, 
    username: "jane_dept", 
    email: "jane@example.com", 
    type: "dept", 
    role: "DROL002", 
    status: "active",
    lastLogin: "Yesterday",
    avatar: "JD", 
    department: "Marketing"
  },
  { 
    id: 3, 
    username: "robert_dev", 
    email: "robert@example.com", 
    type: "dev", 
    role: "DROL001", 
    status: "inactive",
    lastLogin: "2 weeks ago",
    avatar: "RK",
    department: "Engineering" 
  },
  { 
    id: 4, 
    username: "sarah_dept", 
    email: "sarah@example.com", 
    type: "dept", 
    role: "DROL003", 
    status: "active",
    lastLogin: "4 days ago",
    avatar: "SK",
    department: "Sales" 
  },
]

const roles = [
  { id: "DROL001", name: "DevAdmin", color: "blue" },
  { id: "DROL002", name: "System Owner", color: "purple" },
  { id: "DROL003", name: "System Creator", color: "green" },
]

const departments = ["Engineering", "Marketing", "Sales", "Finance", "HR"]

export default function UsersPage() {
  const [userType, setUserType] = useState("dev")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterOpen, setFilterOpen] = useState(false)
  const [statusFilter, setStatusFilter] = useState("all")
  const [departmentFilter, setDepartmentFilter] = useState("all")

  // Apply all filters
  const filteredUsers = dummyUsers.filter(
    (user) =>
      user.type === userType &&
      (statusFilter === "all" || user.status === statusFilter) &&
      (departmentFilter === "all" || user.department === departmentFilter) &&
      (user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  // Get role display info
  const getRoleInfo = (roleId) => {
    const role = roles.find(r => r.id === roleId)
    return {
      name: role?.name || "Unknown",
      color: role?.color || "gray"
    }
  }

  // Status badge colors
  const getStatusColor = (status) => {
    return status === "active" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
  }

  // Role badge colors
  const getRoleBadgeColor = (color) => {
    const colors = {
      blue: "bg-blue-100 text-blue-800 border-blue-200",
      purple: "bg-purple-100 text-purple-800 border-purple-200",
      green: "bg-green-100 text-green-800 border-green-200",
      gray: "bg-gray-100 text-gray-800 border-gray-200"
    }
    return colors[color] || colors.gray
  }

  return (
    <div className="max-w-auto mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold mb-2 flex items-center">
            <UsersIcon className="mr-2 h-6 w-6 text-blue-500" />
            User Management
          </h1>
          <p className="text-gray-600">Manage system users and their permissions</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
            <Download className="h-4 w-4" />
            Export
          </button>
          <button className="flex items-center gap-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
            <Upload className="h-4 w-4" />
            Import
          </button>
          <Link to="/users/create" className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
            <UserPlus className="h-4 w-4" />
            Add User
          </Link>
        </div>
      </div>

      <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-4 flex flex-col items-center justify-center">
          <div className="text-3xl font-bold text-blue-500 mb-2">{dummyUsers.filter(u => u.type === "dev").length}</div>
          <div className="text-gray-600">Developer Users</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4 flex flex-col items-center justify-center">
          <div className="text-3xl font-bold text-purple-500 mb-2">{dummyUsers.filter(u => u.type === "dept").length}</div>
          <div className="text-gray-600">Department Users</div>
        </div>
        <div className="bg-white rounded-lg shadow p-4 flex flex-col items-center justify-center">
          <div className="text-3xl font-bold text-green-500 mb-2">{dummyUsers.filter(u => u.status === "active").length}</div>
          <div className="text-gray-600">Active Users</div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow mb-6">
        <div className="p-4 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex gap-2">
            <button
              onClick={() => setUserType("dev")}
              className={`px-4 py-2 rounded-lg transition-colors ${
                userType === "dev" 
                  ? "bg-blue-500 text-white" 
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              Dev Users
            </button>
            <button
              onClick={() => setUserType("dept")}
              className={`px-4 py-2 rounded-lg transition-colors ${
                userType === "dept" 
                  ? "bg-blue-500 text-white" 
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              Department Users
            </button>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <SearchBar 
              onSearch={setSearchTerm} 
              placeholder="Search users..." 
              className="w-full sm:w-64"
            />
            <div className="relative">
              <button 
                onClick={() => setFilterOpen(!filterOpen)}
                className="flex items-center gap-2 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Filter className="h-4 w-4" />
                Filters
              </button>
              
              {filterOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border z-10 p-4">
                  <h3 className="font-medium mb-3">Filter Users</h3>
                  
                  <div className="mb-3">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="w-full border rounded-lg px-3 py-2"
                    >
                      <option value="all">All Statuses</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                    </select>
                  </div>
                  
                  <div className="mb-3">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                    <select
                      value={departmentFilter}
                      onChange={(e) => setDepartmentFilter(e.target.value)}
                      className="w-full border rounded-lg px-3 py-2"
                    >
                      <option value="all">All Departments</option>
                      {departments.map((dept) => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="flex justify-end mt-4">
                    <button 
                      onClick={() => {
                        setStatusFilter("all");
                        setDepartmentFilter("all");
                      }}
                      className="text-sm text-blue-500 hover:text-blue-700"
                    >
                      Reset Filters
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-gray-50 border-b">
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Department</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Login</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredUsers.map((user) => {
                const roleInfo = getRoleInfo(user.role);
                return (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-medium">
                          {user.avatar}
                        </div>
                        <span className="font-medium">{user.username}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-600">{user.email}</td>
                    <td className="px-6 py-4 text-gray-600">{user.department}</td>
                    <td className="px-6 py-4">
                      <div className="inline-flex">
                        <span className={`px-2.5 py-1 rounded-md text-xs font-medium border ${getRoleBadgeColor(roleInfo.color)}`}>
                          {roleInfo.name}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        {user.status === "active" ? (
                          <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-500 mr-1" />
                        )}
                        <span className={`px-2 py-1 rounded-md text-xs ${getStatusColor(user.status)}`}>
                          {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-600">{user.lastLogin}</td>
                    <td className="px-6 py-4">
                      <div className="flex justify-end gap-2">
                        <button className="p-1 text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded-full transition-colors">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full transition-colors">
                          <Trash2 className="h-4 w-4" />
                        </button>
                        <button className="p-1 text-amber-500 hover:text-amber-700 hover:bg-amber-50 rounded-full transition-colors">
                          <Key className="h-4 w-4" />
                        </button>
                        <div className="relative">
                          <button className="p-1 text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-full transition-colors">
                            <MoreVertical className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {filteredUsers.length === 0 && (
          <div className="p-8 text-center">
            <div className="text-gray-400 mb-2">
              <RefreshCcw className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p className="text-lg font-medium">No users found</p>
            </div>
            <p className="text-gray-500">Try adjusting your search or filter criteria</p>
          </div>
        )}
        
        <div className="p-4 border-t flex justify-between items-center text-sm text-gray-600">
          <div>
            Showing {filteredUsers.length} of {dummyUsers.length} users
          </div>
          <div className="flex gap-2">
            <button disabled className="px-3 py-1 rounded border bg-gray-50 text-gray-400 cursor-not-allowed">
              Previous
            </button>
            <button className="px-3 py-1 rounded border bg-blue-50 text-blue-600">
              1
            </button>
            <button className="px-3 py-1 rounded border hover:bg-gray-50">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}